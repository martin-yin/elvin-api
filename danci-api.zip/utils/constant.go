package utils

const (
	ConfigEnv  = "GVA_CONFIG"
	ConfigFile = "config.yaml"
)
