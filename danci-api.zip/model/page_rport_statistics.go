package model

//type PageReportStatistics struct {
//	global.GVA_MODEL
//	HourName string `json:"hour_name"`
//	HourCount string `json:"hour_count"`
//	DayName string 	`json:"day_name"`
//	DayCount string `json:"day_count"`
//	ActionType string `json:"report_type"`
//	ApiKey string `json:"api_key"`
//}
