package global

import (
	"time"
)

type GVA_MODEL struct {
	ID        uint ``
	CreatedAt time.Time
	UpdatedAt time.Time
}
