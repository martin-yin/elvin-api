package initialize

func InitProject() {
	// 从数据库中取出项目。
}
